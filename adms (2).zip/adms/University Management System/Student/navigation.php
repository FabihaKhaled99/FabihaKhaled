<table>
	<tr><td><a href="courseandresults.php"><h2> &#9783 Courses & Results</h2></a></td></tr>
	<tr><td><a href="registration.php"><h2> &#9889 Registration</h2></a></td></tr>
	<tr><td><a href="offeredcourses.php"><h2> &#128214 Offered Courses</h2></td></tr>
	<tr><td><a href="gradereport.php"><h2> &#10040 Grade report</h2></td></tr>
	<tr><td><a href="profile.php"><h2> &#128101 Profile</h2></td></tr>
</table>