<table>
	<tr>
		<td>
			<a href="portal.php"><img align="left" class="img-logo" src="resources/logo-name.png" /></a>
		</td>
		<td>
			<a href="courseandresults.php"><h2> &#9783 Courses & Results</h2></a>
		</td>
		<td>
			<a href="registration.php"><h2>&nbsp &nbsp &#9889 Registration</h2></a>
		</td>
		<td>
			<a href="gradereport.php"><h2>&nbsp &nbsp &#10040 Grade report</h2></a>
		</td>
		<td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>
		<td>
			<a href="login.php"><h2>Log out &nbsp</h2></a>
		</td>
	</tr>
</table>