<?php include_once "session-header.php" ;?>
<html>
    <head>
	    <title>Student Profile</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body>
	    <div id="container">
		    <fieldset>
			    <div id="header">
				    <?php include_once "header.php";?>
		        </div>
			</fieldset>
		    
			<div id="content">
		        <div id="nav">
				    <?php include_once "navigation.php";?>
		        </div>
				<div id="main">
				    <table>
					    <tr style="background-color: #187fc3;">
						    <td><h1>Notes<h1></td>
						</tr>
					    <tr>
						    <td><h3>1. &nbsp Assignment is uploaded,check it out.</h3></td>
						</tr>
						<tr>
						    <td><hr></td>
						</tr>
						<tr>
						    <td><h3>2. &nbsp Makeup class of last class will be on next sunday.</h3></td>
						</tr>
						<tr>
						    <td><hr></td>
						</tr>
						<tr>
						    <td><h3>3. &nbsp Quiz-1 will be on 21th.Sylebus:lec 1-3.</h3></td>
						</tr>
						<tr>
						    <td><hr></td>
						</tr>
					</table>
		        </div>
		    </div>
		</div>
	</body>
</html>