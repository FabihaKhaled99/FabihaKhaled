<?php
echo "<p>Copyright &copy; 2020</p>";
?>