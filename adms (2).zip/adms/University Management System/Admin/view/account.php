<link rel="stylesheet" type="text/css" href="CSS/account.css">

<?php
echo '<a href="home_mod2.php"class="button">Dasboard</a>';
echo '<a href="logout_mod2.php" class="button">Logout</a> ';


?>