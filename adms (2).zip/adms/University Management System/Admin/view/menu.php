<link rel="stylesheet" type="text/css" href="CSS/menu.css">
<?php
echo "<h1 style='color:blue;'>XYZ University </h1>";
echo "<a href='home_mod2.php' class='button'>Home</a>-
<a href='login_mod2.php' class='button'>Login</a> -
<a href='Registration_mod2.php' class='button'>Registration</a>'"



/*echo '<a href="home_mod2.php" class='button'>Home</a> -
<a href="login_mod2.php" class='button'>Login</a> -
<a href="Registration_mod2.php" class='button'>Registration</a>'*/

?>