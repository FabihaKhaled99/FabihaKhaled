<?php 
include_once "../model/model_r.php";



function fetchAllTeachers(){
	return showAllTeachers();

}
function fetchTeacher($id){
	return showTeacher($id);
	}
